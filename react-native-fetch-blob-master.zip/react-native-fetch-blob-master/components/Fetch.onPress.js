// press button to login
{/*<Fetch.onPress method="POST"
  url="www.example.com/login"
  body={this.state.body}
  onSuccess={this.onSuccess}
  onError={this.showError}>
  <View>
  	<Text>Click to Login</Text>
  </View>
</LoginAction.onPress>*/}
