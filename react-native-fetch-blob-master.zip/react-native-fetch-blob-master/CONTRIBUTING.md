For developers who interested in making contribution to this project, please see [https://github.com/wkh237/react-native-fetch-blob-dev](https://github.com/wkh237/react-native-fetch-blob-dev) for more information.

Please read the following rules before opening a PR :

1. If the PR is offering a feature please make the PR to our "Feature Branch" 0.11.0
2. Bug fix request to "Bug Fix Branch" 0.10.6
3. Correct README.md can directly to master
